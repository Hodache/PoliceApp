package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.cliftonlabs.json_simple.JsonException;
import com.dataclasses.Car;
import com.http.HttpHelper;

import java.io.IOException;

import java.util.ArrayList;

public class CarsActivity extends AppCompatActivity {
    private ArrayList<Car> carsOwned = new ArrayList<>();
    private ArrayList<CardView> cardViews = new ArrayList<>();

    private LinearLayout linear = null;
    private EditText licenseInput = null;
    private Button searchButton = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars);

        linear = (LinearLayout) findViewById(R.id.linear);
        licenseInput = findViewById(R.id.licenseInput);
        searchButton = findViewById(R.id.searchButton);

        this.setTitle("Автомобили водителя");

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeCars();
                showCars();
            }
        });
    }

    private View showCarCard(Car car, ViewGroup root) {
        View cardBody = getLayoutInflater().inflate(R.layout.driver_car_card, null);

        TextView finesText = cardBody.findViewById(R.id.finesCountText);
        finesText.setText(String.valueOf(car.getFinesCount()));

        TextView modelText = cardBody.findViewById(R.id.modelText);
        modelText.setText(car.getModel());

        TextView plateText = cardBody.findViewById(R.id.plateText);
        plateText.setText(car.getPlateNumber());

        TextView colorText = cardBody.findViewById(R.id.colorText);
        colorText.setText(car.getColor());

        TextView insuranceText = cardBody.findViewById(R.id.insuranceText);
        insuranceText.setText(car.getInsurance());

        root.addView(cardBody);

        return cardBody;
    }

    private void showCars () {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    carsOwned = HttpHelper.getCarsList(licenseInput.getText().toString());
                } catch (JsonException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    Dialog dialog = new Dialog(getApplicationContext());
                    dialog.setTitle("Произошла ошибка");
                    dialog.show();
                    e.printStackTrace();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (Car car: carsOwned) {
                            CardView card = (CardView) showCarCard(car, linear);
                            if (carsOwned.indexOf(car) % 2 == 0)
                                card.setBackgroundColor(getColor(R.color.teal_200));

                            cardViews.add(card);
                        }
                    }
                });
            }
        });

        thread.start();
    }

    private void removeCars () {
        for (CardView card: cardViews) {
            linear.removeView(card);
        }
    }
}